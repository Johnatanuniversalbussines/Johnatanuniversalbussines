import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';

Future add(
  BuildContext context, {
  List<FFUploadedFile>? agregar,
  String? adjuntararchivo,
}) async {}
