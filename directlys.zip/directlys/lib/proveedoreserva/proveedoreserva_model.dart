import '/flutter_flow/flutter_flow_util.dart';
import 'proveedoreserva_widget.dart' show ProveedoreservaWidget;
import 'package:flutter/material.dart';

class ProveedoreservaModel extends FlutterFlowModel<ProveedoreservaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
