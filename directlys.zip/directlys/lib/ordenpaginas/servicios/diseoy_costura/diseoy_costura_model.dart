import '/flutter_flow/flutter_flow_util.dart';
import 'diseoy_costura_widget.dart' show DiseoyCosturaWidget;
import 'package:flutter/material.dart';

class DiseoyCosturaModel extends FlutterFlowModel<DiseoyCosturaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;
  // State field(s) for Checkbox widget.
  bool? checkboxValue4;
  // State field(s) for Checkbox widget.
  bool? checkboxValue5;
  // State field(s) for Checkbox widget.
  bool? checkboxValue6;
  // State field(s) for Checkbox widget.
  bool? checkboxValue7;
  // State field(s) for Checkbox widget.
  bool? checkboxValue8;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
