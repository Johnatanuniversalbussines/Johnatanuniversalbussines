import '/flutter_flow/flutter_flow_util.dart';
import 'servicio_tcnico_widget.dart' show ServicioTcnicoWidget;
import 'package:flutter/material.dart';

class ServicioTcnicoModel extends FlutterFlowModel<ServicioTcnicoWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;
  // State field(s) for Checkbox widget.
  bool? checkboxValue4;
  // State field(s) for Checkbox widget.
  bool? checkboxValue5;
  // State field(s) for Checkbox widget.
  bool? checkboxValue6;
  // State field(s) for Checkbox widget.
  bool? checkboxValue7;
  // State field(s) for Checkbox widget.
  bool? checkboxValue8;
  // State field(s) for Checkbox widget.
  bool? checkboxValue9;
  // State field(s) for Checkbox widget.
  bool? checkboxValue10;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
