import '/flutter_flow/flutter_flow_util.dart';
import 'sectordelturismo_widget.dart' show SectordelturismoWidget;
import 'package:flutter/material.dart';

class SectordelturismoModel extends FlutterFlowModel<SectordelturismoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
