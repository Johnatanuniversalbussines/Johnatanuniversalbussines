import '/flutter_flow/flutter_flow_util.dart';
import 'profesionalesen_ensayo_inspecciny_certificacinde_productos_widget.dart'
    show ProfesionalesenEnsayoInspeccinyCertificacindeProductosWidget;
import 'package:flutter/material.dart';

class ProfesionalesenEnsayoInspeccinyCertificacindeProductosModel
    extends FlutterFlowModel<
        ProfesionalesenEnsayoInspeccinyCertificacindeProductosWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;
  // State field(s) for Checkbox widget.
  bool? checkboxValue4;
  // State field(s) for Checkbox widget.
  bool? checkboxValue5;
  // State field(s) for Checkbox widget.
  bool? checkboxValue6;
  // State field(s) for Checkbox widget.
  bool? checkboxValue7;
  // State field(s) for Checkbox widget.
  bool? checkboxValue8;
  // State field(s) for Checkbox widget.
  bool? checkboxValue9;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
