import '/flutter_flow/flutter_flow_util.dart';
import 'localizador_widget.dart' show LocalizadorWidget;
import 'package:flutter/material.dart';

class LocalizadorModel extends FlutterFlowModel<LocalizadorWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for PlacePicker widget.
  FFPlace placePickerValue = const FFPlace();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
