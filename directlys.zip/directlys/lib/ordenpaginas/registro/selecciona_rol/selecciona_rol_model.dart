import '/flutter_flow/flutter_flow_util.dart';
import 'selecciona_rol_widget.dart' show SeleccionaRolWidget;
import 'package:flutter/material.dart';

class SeleccionaRolModel extends FlutterFlowModel<SeleccionaRolWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
