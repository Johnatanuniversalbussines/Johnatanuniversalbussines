import '/flutter_flow/flutter_flow_util.dart';
import 'logos_widget.dart' show LogosWidget;
import 'package:flutter/material.dart';

class LogosModel extends FlutterFlowModel<LogosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
