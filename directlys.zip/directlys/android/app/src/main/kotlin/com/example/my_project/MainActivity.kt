package com.mycompany.directlys

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
